﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;

namespace Domain
{
    /// <summary>
    /// <author>Jens Schwee & Jacob Michelsen</author>
    /// <date>14/09/2015</date>
    /// </summary>
    public class ContractManager
    {
        public void RegisterLeasing(Business business, double rentPerMonth, DateTime startRentPeriod, DateTime rentPeriodEnd)
        {

        }

        public void RegisterSale(Private privatee, List<Car> carListContract)
        {

        }

        public void GetSale()
        {

        }

        public void GetLeasing()
        {
        }
    }
}
